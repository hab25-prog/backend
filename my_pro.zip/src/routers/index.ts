import { Router } from "express";

import userRoutes from "../module/user/user.route.js";
const routers=Router();
routers.use("/user",userRoutes)
export default routers;