import type { Request, Response, NextFunction } from "express";
import Jwt from "jsonwebtoken";
import { env } from "../config/env.js";

interface JwtPayload {
  id: string;
  role: string;
  userName: string;
}

interface AuthenticatedRequest extends Request {
  user?: JwtPayload;
}

export function authMiddleWare(
  userPayload: {
    id: string;
    role: string;
    userName: string;
  },
  res: Response,
) {
  const token = Jwt.sign(userPayload, env.JWT_SECRET, { expiresIn: "1d" });
  res.cookie("jwt", token, {
    httpOnly: true, // Blocks JavaScript access (XSS Protection)
    sameSite: "strict", // Blocks cross-site requests (CSRF Protection)
    maxAge: 24 * 60 * 60 * 1000, // Explicit expiration matching the JWT (1 day in ms)
    path: "/", // Ensures the cookie is accessible across all routes of your API
  });
  console.log("the token is :", token);
  if (token) return token;
  return null
}
export async function isLogin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
) {
  const token = req.cookies.jwt;
  const data = (await Jwt.verify(token, env.JWT_SECRET)) as JwtPayload;
  req.user = data;
  next();
}
