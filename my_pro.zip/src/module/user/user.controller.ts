import type { Request, Response } from "express";
import { UserService } from "./user.service.js";
import Jwt from "jsonwebtoken";
import { env } from "../../config/env.js";
import bcryp from "bcrypt";
import { jwt } from "zod";
import { authMiddleWare } from "../../middleware/auth.middleware.js";

const userService = new UserService();

export const registerUser = async (req: Request, res: Response) => {
  try {
    const data = req.body;
    const user = await userService.register(data);
    authMiddleWare(
      {
        id: user.id,
        role: user.role,
        userName: user.username,
      },
      res,
    );

    res.status(201).json({
      status: "sucess",
      message: "you are registerd successfully",
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message:
        error instanceof Error ? error.message : "Failed to register user",
    });
  }
};
export const login = async (req: Request, res: Response) => {
  const { userName, password } = req.body;
  const user = await userService.loginUser(userName, password);
  const token = authMiddleWare(
    {
      id: user.id,
      userName: user.username,
      role: user.role,
    },
    res,
  );
  if (!token)
    return res
      .status(500)
      .json({ status: "error", message: "enternal server error" });
  res
    .status(200)
    .json({ status: "sucess", message: "you successfully lgged in" });
};

export const fetchMe = async (req: Request, res: Response) => {
  const token = req.cookies.jwt;
  if (!token) {
    res.status(401).json({ status: "error", message: "first login !!" });
    return;
  }
  const decode = Jwt.verify(token, env.JWT_SECRET);
  if (!decode) {
    res.status(401).json({
      status: "error",
      message: "the decode is not correctly verify",
    });
    return;
  }
  res.status(200).json({ status: "ok", data: decode });
};
export const logOut = async (req: Request, res: Response) => {
  res.clearCookie("jwt", {
    httpOnly: true,
    sameSite: "strict",
  });
  res.status(200).json({ status: "ok", message: "sucessfully logout" });
};
