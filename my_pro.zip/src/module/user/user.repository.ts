import { prisma } from "../../config/prisma.js";


export class UserRepository {
async findByEmail(email: string){
    return prisma.user.findUnique({
        where: {email}
    })
}
async findUserById(id: string){
    return prisma.user.findUnique({where: {id: id}})
}
async findUserByUName(username: string){
    return await prisma.user.findUnique({where: {username: username}})
}
async create(data: {
    fullName: string;
    email: string;
    passwordHash: string;
    username: string;

}){
return await prisma.user.create({
    data,
});
}



}


