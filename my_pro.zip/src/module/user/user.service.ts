import bcrypt from "bcrypt";
import { UserRepository } from "./user.repository.js";
import { email } from "zod";
import { ConflictError } from "../../shared/errors/ConflictError.js";
import { NoteFoundError } from "../../shared/errors/NotFoundError.js";
import { UnauthorizedError } from "../../shared/errors/UnauthorizedError.js";
import { authMiddleWare } from "../../middleware/auth.middleware.js";

const userRepository = new UserRepository();
export class UserService {
  async register(data: {
    email: string;
    username: string;
    password: string;
    fullName?: string;
  }) {
    const existingUser = await userRepository.findByEmail(data.email);
    if (existingUser) {
      throw new ConflictError("the user already sigin");
    }
    const passwordHash = await bcrypt.hash(data.password, 10);
    return await userRepository.create({
      email: data.email,
      username: data.username,
      passwordHash,
      fullName: data.fullName ?? "",
    });
  }

  async loginUser(userName: string, password: string) {
    const user = await userRepository.findUserByUName(userName);
    if (!user) {
      throw new NoteFoundError("the user is not found");
    }
    const isPasswordMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordMatch) {
      throw new UnauthorizedError("the password is not correct");
    }
    return user;
  }

  async getUser(data: { username?: string; id?: string }) {
    if (data.username)
      return await userRepository.findUserByUName(data.username);
    if (data.id) return await userRepository.findUserById(data.id);
  }
}
